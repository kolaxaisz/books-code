These are the step-by-step examples for [the Complete Intro to React v6][citr] as taught for [Frontend Masters][fem] by [Brian Holt][twitter].

- Feel free to open pull requests for errors on this repo.
- For issues with this repo, please file them on [the course website's repo][site] (easier for me to track one instead of two repos.)
- For issues with the code website (and not the code samples), [find the code here][site].

[twitter]: https://twitter.com/holtbt
[fem]: https://www.frontendmasters.com
[citr]: https://bit.ly/react-6
[site]: https://github.com/btholt/complete-intro-to-react-v6
