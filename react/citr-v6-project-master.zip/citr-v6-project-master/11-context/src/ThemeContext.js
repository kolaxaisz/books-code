import { createContext } from "react";

const ThemeContext = createContext(["green", () => {}]);

export default ThemeContext;
