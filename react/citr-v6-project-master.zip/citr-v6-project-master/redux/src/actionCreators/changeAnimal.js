export default function changeAnimal(theme) {
  return { type: "CHANGE_ANIMAL", payload: theme };
}
