export default function changeBreed(theme) {
  return { type: "CHANGE_BREED", payload: theme };
}
